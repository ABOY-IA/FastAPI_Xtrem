import streamlit as st

st.title("Bienvenue sur l'application FastAPI Xtrem")
st.write("Utilisez le menu latéral pour naviguer entre les pages : Connexion/Inscription et Modification du profil.")
st.write("Cette application utilise FastAPI pour le backend et Streamlit pour le frontend.")